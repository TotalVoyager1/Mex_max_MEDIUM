// === Защита MEX от трекеров ===
(function() {
    // Список популярных трекеров
    const blockedDomains = [
        // VK / Mail.ru
        "mc.yandex.ru", "top-fwz1.mail.ru", "my.rt", "vk.com/rtrg",
        // Google
        "google-analytics.com", "googletagmanager.com", "gtag/js",
        // Yandex
        "yandex.ru", "yastatic.net", "mcstat.yandex.net",
        // Facebook / Meta
        "connect.facebook.net", "facebook.com/tr",
        // Рекламные сети и ретаргетинг
        "ads.linkedin.com", "doubleclick.net", "adservice.google.com",
        "adroll.com", "criteo.net", "scorecardresearch.com", "quantserve.com",
        "statcounter.com", "statisticstools.net"
    ];

    // Перехват fetch
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
        if (typeof args[0] === 'string' && blockedDomains.some(d => args[0].includes(d))) {
            console.warn("Блокирован fetch-запрос:", args[0]);
            return Promise.resolve(new Response("", { status: 204 }));
        }
        return originalFetch.apply(this, args);
    };

    // Перехват XMLHttpRequest
    const originalXHR = window.XMLHttpRequest;
    window.XMLHttpRequest = function() {
        const xhr = new originalXHR();
        const originalOpen = xhr.open;
        xhr.open = function(method, url, ...rest) {
            if (blockedDomains.some(d => url.includes(d))) {
                console.warn("Блокирован XHR:", url);
                return; // Не отправляем запрос
            }
            return originalOpen.apply(this, [method, url, ...rest]);
        };
        return xhr;
    };

    // Перехват создания скриптов трекеров
    const originalCreateElement = document.createElement.bind(document);
    document.createElement = function(tagName) {
        const element = originalCreateElement(tagName);
        if(tagName.toLowerCase() === 'script') {
            const originalSetAttribute = element.setAttribute.bind(element);
            element.setAttribute = function(attr, value) {
                if(attr === 'src' && blockedDomains.some(d => value.includes(d))) {
                    console.warn("Блокирован скрипт трекера:", value);
                    return; // Не вставляем скрипт
                }
                return originalSetAttribute(attr, value);
            };
        }
        return element;
    };

    }

    console.log("%c[Защита MEX] Все популярные трекеры заблокированы", "color: green; font-weight: bold;");
})();